import customtkinter as ctk
import socket
import psutil
import netifaces 
# Aparência
ctk.set_appearance_mode('dark')

# Funções
def teste_de_conexao():
    import socket
import psutil
import netifaces
import customtkinter as ctk

def teste_de_conexao():
    # Verifica conexão com internet
    try:
        socket.create_connection(("8.8.8.8", 53), timeout=3)
        status = "🌎 Conectado à Internet\n\n"
        conectado = True
    except OSError:
        status = "❌ Sem Conexão com a Internet\n\n"
        conectado = False

    ipv4 = mac = dns = gateway = "Não Encontrado."

    if conectado:
        # Captura interfaces ativas
        addrs = psutil.net_if_addrs()
        for iface_name, iface_addrs in addrs.items():
            for addr in iface_addrs:
                if addr.family == socket.AF_INET and addr.address != "127.0.0.1":
                    ipv4 = addr.address
                elif addr.family == psutil.AF_LINK:
                    mac = addr.address
            if ipv4 != "Não Encontrado.":
                break

        # Gateway padrão
        try:
            gw = netifaces.gateways()
            gateway = gw['default'][netifaces.AF_INET][0]
        except:
            gateway = "Não Encontrado."

        # DNS (exemplo simples, pode ser aprimorado)
        dns = "177.38.48.6"  # fallback

    # Monta resultado
    info = (
        status +
        f"Endereço IPv4: {ipv4}\n"
        f"Gateway Padrão: {gateway}\n"
        f"Servidor DNS: {dns}\n"
        f"Endereço físico (MAC): {mac}"
    )

    textbox.configure(state="normal")
    textbox.delete("1.0", "end")
    textbox.insert("1.0", info)
    textbox.configure(state="disabled")


def selecionar_acao(choice):
    if choice == "Testar Conexão":
        teste_de_conexao()
    else:
        textbox.configure(state="normal")
        textbox.delete("1.0", "end")
        textbox.insert("1.0", f"Ação selecionada: {choice}")
        textbox.configure(state="disabled")


# Janela Principal
app = ctk.CTk()
app.title('Sistema de Correção de Internet')
app.geometry('940x500')

frame_head = ctk.CTkFrame(app, width=920, height=100, fg_color='SkyBlue4')
frame_head.place(x=10, y=5)

frame1 = ctk.CTkFrame(master=app,  width=150, height=380, fg_color='SkyBlue4')
frame1.place(x=10, y=110)
frame1.pack_propagate(False)

frame_home = ctk.CTkFrame(app, width=765, height=380, fg_color='SkyBlue4')
frame_home.place(x=165, y=110)
frame_home.pack_propagate(False)

# Campos de Informação
menu = ctk.CTkOptionMenu(frame_home,
                         values=["Testar Conexão", "Renovar IP", "Limpar DNS", "Resetar Winsock",
                                 "Corrigir Tudo"],
                         width=250,
                         font=('arial bold', 15),
                         height=35,
                         button_color='green',
                         fg_color='green',
                         dropdown_fg_color='SkyBlue4',
                         dropdown_font=('arial bold', 15),
                         command=selecionar_acao
                         )
menu.pack(pady=5)
menu.set("Escolha uma Opção")

textbox = ctk.CTkTextbox(frame_home, width=350, height=350)
textbox.pack(pady=10)

button = ctk.CTkButton(frame1, text='Editar')
button.pack()

app.mainloop()